package ru.alexeypostnov.lesson11

import androidx.compose.runtime.staticCompositionLocalOf

val LocalName = staticCompositionLocalOf {
    "Это приложение"
}