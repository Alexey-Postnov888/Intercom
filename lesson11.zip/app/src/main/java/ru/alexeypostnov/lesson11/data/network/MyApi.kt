package ru.alexeypostnov.lesson11.data.network

// Retrofit
interface MyApi {
    // @GET("/")
    fun callApi(): String
}