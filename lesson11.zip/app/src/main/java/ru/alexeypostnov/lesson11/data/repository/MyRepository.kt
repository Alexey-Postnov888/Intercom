package ru.alexeypostnov.lesson11.data.repository

import ru.alexeypostnov.lesson11.data.network.MyApi

interface MyRepository {
    fun callApi(): String
}

class MyRepositoryImpl(
    private val service: MyApi
): MyRepository {
    override fun callApi(): String {
        return service.callApi()
    }
}
