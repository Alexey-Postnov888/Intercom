package ru.alexeypostnov.lesson11.di

import android.util.Log
import org.koin.core.module.dsl.factoryOf
import org.koin.core.module.dsl.singleOf
import org.koin.core.module.dsl.viewModel
import org.koin.dsl.module
import org.koin.dsl.bind
import org.koin.dsl.binds
import ru.alexeypostnov.lesson11.data.network.MyApi
import ru.alexeypostnov.lesson11.data.repository.MyRepository
import ru.alexeypostnov.lesson11.data.repository.MyRepositoryImpl
import ru.alexeypostnov.lesson11.domain.CallApiUseCase
import ru.alexeypostnov.lesson11.domain.CallApiUseCaseImpl
import ru.alexeypostnov.lesson11.presentation.main.MainViewModel

val appModule = module {
    single {
//        Retrofit.builder()
        object : MyApi {
            override fun callApi(): String {
                Log.d("Hello from Koin", "DI works!!!")
                return "DI works!!!"
            }
        }
    } bind MyApi::class

    singleOf(::MyRepositoryImpl) bind(MyRepository::class)

    factoryOf(::CallApiUseCaseImpl) bind(CallApiUseCase::class)

//    single {
//        MyRepositoryImpl(
//            get()
//        )
//    } bind MyRepository::class
//
//    factory {
//        CallApiUseCaseImpl(
//            get()
//        )
//    } bind CallApiUseCase::class
}

val viewModelModule = module {
    viewModel {
        MainViewModel(get())
    }
}