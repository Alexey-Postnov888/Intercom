package ru.alexeypostnov.lesson11.domain

import ru.alexeypostnov.lesson11.data.repository.MyRepository

interface CallApiUseCase {
    operator fun invoke(): String
}

class CallApiUseCaseImpl(
    private val repository: MyRepository
): CallApiUseCase {
    override fun invoke(): String =
        repository.callApi()
}