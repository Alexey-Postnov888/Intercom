package ru.alexeypostnov.lesson11.presentation.config

import android.widget.Toast
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import ru.alexeypostnov.lesson11.LocalName

@Composable
fun ConfigBottomSheetScreen() {
    ConfigBottomSheetScreenContent()

}
@Composable
fun ConfigBottomSheetScreenContent(
) {
    val name = LocalName.current
    val context = LocalContext.current
    LaunchedEffect(Unit) {
        Toast
            .makeText(context, name, Toast.LENGTH_SHORT).show()
    }
    Column(
        modifier = Modifier
            .fillMaxWidth()
    ) {
        Text("Hello")
        Text("World")
        Text("Hello")
        Text("Hello")
        Text("Hello")
    }
}

@Composable
@Preview
fun ConfigBottomSheetScreenPreview() {
    ConfigBottomSheetScreenContent()
}