package ru.alexeypostnov.lesson11.presentation.details

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import cafe.adriel.voyager.navigator.LocalNavigator
import ru.alexeypostnov.lesson11.presentation.main.MainScreePreview

@Composable
fun DetailsScreen() {
    val navigator = LocalNavigator.current
    DetailsScreenContent(
        onGoBackClick = {
            navigator?.pop()
        }
    )
}

@Composable
fun DetailsScreenContent(
    onGoBackClick: () -> Unit
) {
    Scaffold { innerPadding ->
        Box(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .background(Color.Green)
        ) {
            Column(
                modifier = Modifier
                    .align(Alignment.Center)
            ) {
                Button(
                    onClick = {
                        onGoBackClick()
                    }
                ) {
                    Text("Go back")
                }
            }
        }
    }
}

@Composable
@Preview
fun DetailsScreePreview() {
    DetailsScreenContent(onGoBackClick = {})
}