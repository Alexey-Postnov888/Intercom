package ru.alexeypostnov.lesson11.presentation.main

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.lifecycle.viewmodel.compose.viewModel
import cafe.adriel.voyager.navigator.LocalNavigator
import cafe.adriel.voyager.navigator.bottomSheet.LocalBottomSheetNavigator
import org.koin.androidx.compose.koinViewModel
import ru.alexeypostnov.lesson11.navigation.BottomSheetNavigationScreen
import ru.alexeypostnov.lesson11.navigation.DetailsNavigationScreen
import ru.alexeypostnov.lesson11.presentation.config.ConfigBottomSheetScreen

@Composable
fun MainScreen() {
    val navigator = LocalNavigator.current?.parent?.parent
    val bsNavigator = LocalBottomSheetNavigator.current

    val viewModel: MainViewModel = koinViewModel()

    MainScreenContent(
        onGoToDetailsScreenClick = {
            navigator?.push(DetailsNavigationScreen())
        },
        onShowBottomSheetClick = {
            bsNavigator.show(BottomSheetNavigationScreen())
        },
        onCallApiClick = {
            viewModel.callApi()
        }
    )
}

@Composable
fun MainScreenContent(
    onGoToDetailsScreenClick: () -> Unit,
    onShowBottomSheetClick: () -> Unit,
    onCallApiClick: () -> Unit
) {
    val context = LocalContext.current
    var count by remember {
        mutableStateOf(0)
    }
    LaunchedEffect(count) {
        Toast.makeText(context, "Начало композиции $count", Toast.LENGTH_LONG).show()
    }
    DisposableEffect(count) {
        onDispose {
            Toast.makeText(context, "Конец композиции $count", Toast.LENGTH_LONG).show()
        }
    }

    Scaffold { innerPadding ->
        Box(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .background(Color.Red)
        ) {
            Column(
                modifier = Modifier
                    .align(Alignment.Center)
            ) {
                Button(
                    onClick = {
                        onGoToDetailsScreenClick()
                    }
                ) {
                    Text("Go forward")
                }
                Button(
                    onClick = {
                        count++
                    }
                ) {
                    Text("Click: $count")
                }
                Button(
                    onClick = {
                        onShowBottomSheetClick()
                    }
                ) {
                    Text("Show bottom sheet")
                }
                Button(
                    onClick = {
                        onCallApiClick()
                    }
                ) {
                    Text("Call api")
                }
            }
        }
    }
}

@Composable
@Preview
fun MainScreePreview() {
    MainScreenContent(
        onGoToDetailsScreenClick = {},
        onShowBottomSheetClick = {},
        onCallApiClick = {}
    )
}