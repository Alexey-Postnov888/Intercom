package ru.alexeypostnov.lesson11.presentation.main

import androidx.lifecycle.ViewModel
import ru.alexeypostnov.lesson11.domain.CallApiUseCase

class MainViewModel(
    private val callApiUseCase: CallApiUseCase
): ViewModel() {
    fun callApi() {
        callApiUseCase()
    }
}